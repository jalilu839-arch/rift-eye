package com.chomsmp.rifteye;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.world.EntitiesLoadEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Transformation;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public final class RiftEyePlugin extends JavaPlugin implements Listener, TabExecutor {

    private static final String TAG = "rifteye_vfx";

    private final Map<UUID, ItemDisplay> rifts = new HashMap<>();
    private BukkitTask task;
    private long tick;

    // config values
    private List<String> frames = new ArrayList<>();
    private int frameTicks;
    private float scale;
    private double offsetY;
    private Display.Billboard billboard;
    private int brightness;
    private float viewRange;
    private double spin;
    private boolean pulse;
    private float pulseAmount;
    private int interval;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadSettings();
        getServer().getPluginManager().registerEvents(this, this);
        var cmd = getCommand("rift");
        if (cmd != null) {
            cmd.setExecutor(this);
            cmd.setTabCompleter(this);
        }
        for (World w : Bukkit.getWorlds()) {
            for (Entity e : w.getEntitiesByClass(ItemDisplay.class)) {
                track(e);
            }
        }
        refreshAll();
        startLoop();
    }

    @Override
    public void onDisable() {
        if (task != null) task.cancel();
        rifts.clear();
    }

    // ---------------------------------------------------------------- settings

    private void loadSettings() {
        reloadConfig();
        var c = getConfig();

        frames = new ArrayList<>(c.getStringList("frames"));
        if (frames.isEmpty()) frames.add(c.getString("model", "studio:rift_eye"));
        frameTicks = Math.max(1, c.getInt("frame-ticks", 4));

        scale = (float) c.getDouble("scale", 3.0);
        offsetY = c.getDouble("offset-y", 1.5);
        brightness = c.getInt("brightness", 15);
        viewRange = (float) c.getDouble("view-range", 4.0);

        try {
            billboard = Display.Billboard.valueOf(c.getString("billboard", "CENTER").toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ex) {
            billboard = Display.Billboard.CENTER;
        }

        spin = c.getDouble("loop.spin-degrees-per-second", 0);
        pulse = c.getBoolean("loop.pulse", false);
        pulseAmount = (float) c.getDouble("loop.pulse-amount", 0.15);
        interval = Math.max(1, c.getInt("loop.interval-ticks", 20));
    }

    // ----------------------------------------------------------------- display

    private ItemStack modelItem(String id) {
        NamespacedKey key = NamespacedKey.fromString(id);
        if (key == null) key = new NamespacedKey("studio", "rift_eye");
        ItemStack item = new ItemStack(Material.PAPER);
        ItemMeta meta = item.getItemMeta();
        meta.setItemModel(key);
        item.setItemMeta(meta);
        return item;
    }

    private void applyTransform(ItemDisplay d, long step, int duration) {
        double stepDegrees = spin * interval / 20.0;
        float angle = (float) Math.toRadians((stepDegrees * step) % 360.0);
        float s = scale;
        if (pulse) s *= 1f + ((step % 2 == 0) ? pulseAmount : -pulseAmount);

        Transformation t = new Transformation(
                new Vector3f(),
                new AxisAngle4f(angle, 0f, 1f, 0f),
                new Vector3f(s, s, s),
                new AxisAngle4f()
        );
        d.setInterpolationDelay(0);
        d.setInterpolationDuration(duration);
        d.setTransformation(t);
    }

    private void configure(ItemDisplay d) {
        d.setItemStack(modelItem(frames.get(0)));
        d.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.FIXED);
        d.setBillboard(billboard);
        d.setViewRange(viewRange);
        d.setBrightness(brightness >= 0 ? new Display.Brightness(brightness, brightness) : null);
        applyTransform(d, 0, 0);
    }

    private void refreshAll() {
        for (ItemDisplay d : rifts.values()) configure(d);
    }

    // -------------------------------------------------------------------- loop

    private void startLoop() {
        if (task != null) task.cancel();
        task = Bukkit.getScheduler().runTaskTimer(this, this::tickLoop, 1L, 1L);
    }

    private void tickLoop() {
        tick++;
        rifts.values().removeIf(d -> !d.isValid());
        if (rifts.isEmpty()) return;

        boolean cycleFrames = frames.size() > 1 && tick % frameTicks == 0;
        boolean retransform = (spin != 0 || pulse) && tick % interval == 0;
        if (!cycleFrames && !retransform) return;

        for (ItemDisplay d : rifts.values()) {
            if (cycleFrames) {
                int idx = (int) ((tick / frameTicks) % frames.size());
                d.setItemStack(modelItem(frames.get(idx)));
            }
            if (retransform) applyTransform(d, tick / interval, interval);
        }
    }

    private void track(Entity e) {
        if (e instanceof ItemDisplay d && d.getScoreboardTags().contains(TAG)) {
            rifts.put(d.getUniqueId(), d);
            configure(d);
        }
    }

    @EventHandler
    public void onEntitiesLoad(EntitiesLoadEvent event) {
        for (Entity e : event.getEntities()) track(e);
    }

    // ---------------------------------------------------------------- commands

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("rift.admin")) {
            sender.sendMessage("§cYou don't have permission.");
            return true;
        }
        if (args.length == 0) {
            sender.sendMessage("§eUsage: /rift <set|remove [radius]|reload>");
            return true;
        }

        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "set" -> {
                if (!(sender instanceof Player p)) {
                    sender.sendMessage("§cPlayers only.");
                    return true;
                }
                Location loc = p.getLocation().add(0, offsetY, 0);
                loc.setYaw(0f);
                loc.setPitch(0f);
                ItemDisplay d = p.getWorld().spawn(loc, ItemDisplay.class, e -> {
                    e.addScoreboardTag(TAG);
                    e.setPersistent(true);
                });
                rifts.put(d.getUniqueId(), d);
                configure(d);
                p.sendMessage("§aRift eye set. It will loop automatically.");
            }
            case "remove" -> {
                if (!(sender instanceof Player p)) {
                    sender.sendMessage("§cPlayers only.");
                    return true;
                }
                double r = 3;
                if (args.length > 1) {
                    try {
                        r = Math.min(64, Math.max(1, Double.parseDouble(args[1])));
                    } catch (NumberFormatException ex) {
                        p.sendMessage("§cRadius must be a number.");
                        return true;
                    }
                }
                int removed = 0;
                for (Entity e : p.getNearbyEntities(r, r, r)) {
                    if (e instanceof ItemDisplay d && d.getScoreboardTags().contains(TAG)) {
                        rifts.remove(d.getUniqueId());
                        d.remove();
                        removed++;
                    }
                }
                p.sendMessage(removed > 0
                        ? "§aRemoved " + removed + " rift(s)."
                        : "§cNo rift within " + (int) r + " blocks.");
            }
            case "reload" -> {
                loadSettings();
                refreshAll();
                sender.sendMessage("§aRiftEye config reloaded.");
            }
            default -> sender.sendMessage("§eUsage: /rift <set|remove [radius]|reload>");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            List<String> out = new ArrayList<>();
            for (String s : List.of("set", "remove", "reload")) {
                if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) out.add(s);
            }
            return out;
        }
        return List.of();
    }
}
