RiftEye - /rift set places a looping studio:rift_eye VFX where you stand.

Target:  Paper 1.21.11 (paper-api 1.21.11-R0.1-SNAPSHOT, api-version 1.21.11)
Build:   mvn package        (needs Java 21 + internet for the Paper API)
Output:  target/RiftEye-1.0.0.jar  -> put in your server's plugins/ folder

Commands (permission rift.admin, default op):
  /rift set              place a rift at your position
  /rift remove [radius]  remove rifts near you (default 3 blocks)
  /rift reload           reload config.yml

The studio:rift_eye item model (assets/studio/items/rift_eye.json) must be in
the resource pack your players use. It is NOT in the Chom_Smp.zip you uploaded.
